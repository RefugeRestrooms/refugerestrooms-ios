Copyright (c) 2012, Applidium

This file contains the list of people involved in the development
of ADClusterMapView along its history.

==========================================================

* Romain Goyet
    - Initial research: implemented and tested various algorithms (naive, k-means, quadtree) before choosing the one using a k-d tree.
    - Initial animation code using two pools of annotations
* Patrick Nollet
    - Cluster classification using PCA (Principal Component Analysis)
    - Final animation code
    - Implementation of current architecture (MKMapView subclass)
