//
//  CDStreetlightsMapViewController.m
//  ClusterDemo
//
//  Created by Patrick Nollet on 11/10/12.
//  Copyright (c) 2012 Applidium. All rights reserved.
//

#import "CDStreetlightsMapViewController.h"

@implementation CDStreetlightsMapViewController
- (NSString *)pictoName {
    return @"CDStreetlight.png";
}

- (NSString *)clusterPictoName {
    return @"CDStreetlightCluster.png";
}

- (NSString *)seedFileName {
    return @"CDStreetlights";
}
@end
