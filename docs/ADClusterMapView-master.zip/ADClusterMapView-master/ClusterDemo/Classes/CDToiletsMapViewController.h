//
//  CDToiletMapViewController.h
//  ClusterDemo
//
//  Created by Patrick Nollet on 11/10/12.
//  Copyright (c) 2012 Applidium. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "CDMapViewController.h"

@interface CDToiletsMapViewController : CDMapViewController

@end
