//
//  TPSDetailViewController.h
//  Sample-UISearchController
//
//  Created by James Dempsey on 7/4/14.
//  Copyright (c) 2014 Tapas Software. All rights reserved.
//
//  Based on Apple sample code TableSearch version 2.0
//

#import <UIKit/UIKit.h>

@class Product;

@interface DetailViewController : UIViewController

@property (nonatomic, strong) Product *product;

@end
