//
//  SearchResultCollectionViewCell.h
//  Sample-UISearchController
//
//  Created by James Dempsey on 7/5/14.
//  Copyright (c) 2014 Tapas Software. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SearchResultCollectionViewCell : UICollectionViewCell

@property (nonatomic, weak) IBOutlet UILabel *titleLabel;

@end
